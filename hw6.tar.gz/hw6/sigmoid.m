function result=sigmoid(X)
    result = 1./(1+exp(-1. * X));